    </div>

    <!-- Footer -->
    <footer class="sticky-footer" style="background-color: #000080; padding: 1rem; margin-top: 18rem;">
        <div class="container my-auto" style="color: #FFF;">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Food Order System <script>document.write(new Date().getFullYear());</script></span><br>
        </div>
        </div>
    </footer>

    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
