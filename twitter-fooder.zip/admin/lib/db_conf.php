<?php
    $servername = "localhost";
    $dbname = "foodordering";
    $username = "root";
    $password = "";
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
?>
