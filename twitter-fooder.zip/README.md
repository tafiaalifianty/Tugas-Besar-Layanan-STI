# Tafia Alifianty Web Based Food Ordering System

Repository ini memuat source code untuk sistem berbasis web 
dalam memanajemen order makanan dan paket makanan. Web ini 
dikembangkan menggunakan PHP, Js, dan Bootstrap. Sistem ini 
memuat fitur pemesanan makanan serta paket bagi pelanggan 
dimana pelanggan cukup memasukan nama dan nomor teleponya 
ketika ingin melakukan pengorderan. Admin dapat melakukan 
ekspor data customer dan nomor teleponya serta memanajemen 
data makanan dan paket.